#include "u32_to_hexstring.h"

int8_t U32_to_HexString(char *string, int len, uint32_t val, uint8_t leadingZero)
{
  int8_t ret;
  uint32_t valOpposite = 0;
  uint8_t digits = 0;
  char *ptr = string;
  if (len == 0)
  { /* invalid input buffer length */
    return 2;
  }
  while (val != 0)
  {
    digits++;
    valOpposite = (valOpposite << 4) | (val & 0x0F);
    val = val >> 4;
  }
  if (digits > len)
  { /* return value: value is only partly displayed */
    ret = 1;
    valOpposite = (valOpposite >> ((digits - len) * 4));
  }else
  {
    ret = 0;
  }
  if (leadingZero)
  {
    while (len > digits)
    {
      *ptr = '0';
      ptr++;
      len--;
    }
  }else
  {
    if (valOpposite == 0)
    {
      len = 1;
    }else
    {
      if (len > digits)
      {
        len = digits;
      }
    }
  }
  while (len != 0)
  {
    uint8_t digit = valOpposite & 0x0F;
    valOpposite = valOpposite >> 4;
    *ptr = (digit < 10) ? ('0' + digit) : ('A' + digit - 10);
    ptr++;
    len--;
  }
  return ret;
}
