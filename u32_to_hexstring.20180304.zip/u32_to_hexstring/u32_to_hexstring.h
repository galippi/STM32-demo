#ifndef _U32_TO_HEXSTRING_H_
#define _U32_TO_HEXSTRING_H_

#include <stdint.h>

int8_t U32_to_HexString(char *string, int len, uint32_t val, uint8_t leadingZero);

#endif /* _U32_TO_HEXSTRING_H_ */
