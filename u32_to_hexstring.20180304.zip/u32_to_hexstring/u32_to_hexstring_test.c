#include <stdio.h>
#include <memory.h>
#include <assert.h>
#include "u32_to_hexstring.h"

int U32_to_HexString_test_raw(uint32_t val, uint8_t len, uint8_t leadingZero, int8_t ret, char *expectedResultStr)
{
  char buf[len + 1];
  memset(buf, 0, sizeof(buf));
  int8_t result = U32_to_HexString(buf, len, val, leadingZero);
  return ((ret == result) && (strcmp(buf, expectedResultStr) == 0));
}

void U32_to_HexString_test(uint32_t val, uint8_t len, uint8_t leadingZero, int8_t ret)
{
  char buf[len + 1];
  char expectedResultStr[len + 1];
  uint32_t convertedVal = val;
  printf("Test case: %08X %d %u %d\n", val, len, leadingZero, ret);
  if (len == 0)
  {
    assert(U32_to_HexString(buf, len, val, leadingZero) == ret);
    return;
  }
  if (len < 8)
  {
    convertedVal = convertedVal & (0xFFFFFFFF >> ((8 - len) * 4));
  }
  assert(len < 100);
  char format[6];
  if (leadingZero)
  {
    sprintf(format, "%%0%dX", len);
  }else
  {
    strcpy(format, "%X");
  }
  snprintf(expectedResultStr, len + 1, format, convertedVal);
  printf("expectedResultStr = %s format=%s!\n", expectedResultStr, format);
  assert(U32_to_HexString_test_raw(val, len, leadingZero, ret, expectedResultStr));
}

int main(int argc, const char **argv)
{
  char buf[12];
  memset(buf, 0, sizeof(buf));
  printf("%8X %4d %s!\n", 0x1234abcd, U32_to_HexString(buf, 8, 0x1234abcd, 0), buf);
  memset(buf, 0, sizeof(buf));
  printf("%8X %4d %s!\n", 0x1234abcd, U32_to_HexString(buf, 8, 0x1234abcd, 1), buf);
  memset(buf, 0, sizeof(buf));
  printf("%8X %4d %s!\n", 0x1234abcd, U32_to_HexString(buf, 7, 0x1234abcd, 1), buf);
  memset(buf, 0, sizeof(buf));
  printf("%8X %4d %s!\n", 0x1A, U32_to_HexString(buf, 8, 0x1A, 0), buf);
  memset(buf, 0, sizeof(buf));
  printf("%8X %4d %s!\n", 0x1A, U32_to_HexString(buf, 8, 0x1A, 1), buf);
  assert(U32_to_HexString_test_raw(0x00, 0, 0, 2, ""));
  assert(U32_to_HexString_test_raw(0x00, 1, 0, 0, "0"));
  assert(U32_to_HexString_test_raw(0x10, 1, 0, 1, "0"));
  U32_to_HexString_test(0x00000000, 0, 0, 2);
  U32_to_HexString_test(0x00000000, 0, 1, 2);
  U32_to_HexString_test(0x00000000, 1, 0, 0);
  U32_to_HexString_test(0x00000000, 1, 1, 0);
  U32_to_HexString_test(0x00000000, 5, 0, 0);
  U32_to_HexString_test(0x00000000, 5, 1, 0);
  U32_to_HexString_test(0x00000001, 1, 0, 0);
  U32_to_HexString_test(0x00000009, 1, 0, 0);
  U32_to_HexString_test(0x0000000A, 1, 0, 0);
  U32_to_HexString_test(0x0000000F, 1, 0, 0);
  U32_to_HexString_test(0x00000001, 2, 0, 0);
  U32_to_HexString_test(0x00000009, 2, 0, 0);
  U32_to_HexString_test(0x0000000A, 2, 0, 0);
  U32_to_HexString_test(0x0000000F, 2, 0, 0);
  U32_to_HexString_test(0x00000001, 2, 1, 0);
  U32_to_HexString_test(0x00000009, 2, 1, 0);
  U32_to_HexString_test(0x0000000A, 2, 1, 0);
  U32_to_HexString_test(0x0000000F, 2, 1, 0);
  U32_to_HexString_test(0x99999999, 8, 0, 0);
  U32_to_HexString_test(0x99999999, 8, 1, 0);
  U32_to_HexString_test(0x99999999, 9, 0, 0);
  U32_to_HexString_test(0x99999999, 9, 1, 0);
  U32_to_HexString_test(0xFFFFFFFF, 8, 0, 0);
  U32_to_HexString_test(0xFFFFFFFF, 8, 1, 0);
  U32_to_HexString_test(0xFFFFFFFF, 9, 0, 0);
  U32_to_HexString_test(0xFFFFFFFF, 9, 1, 0);

  U32_to_HexString_test(0x00000010, 1, 0, 1);
  U32_to_HexString_test(0x00000011, 1, 0, 1);
  U32_to_HexString_test(0x00000019, 1, 0, 1);
  U32_to_HexString_test(0x0000001A, 1, 0, 1);
  U32_to_HexString_test(0x0000001F, 1, 0, 1);

  U32_to_HexString_test(0x011039AF, 6, 0, 1);
  U32_to_HexString_test(0x011039AF, 6, 1, 1);
  U32_to_HexString_test(0x110039AF, 7, 0, 1);
  U32_to_HexString_test(0x110039AF, 7, 1, 1);
  U32_to_HexString_test(0x110039AF, 8, 0, 0);
  U32_to_HexString_test(0x110039AF, 8, 1, 0);

  printf("U32_to_HexString is ok!\n");
  return 0;
}
